package com.example.stitchesandrows

import android.annotation.SuppressLint
import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import android.widget.EditText
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    private lateinit var timerViewModel: TimerViewModel
    private var stitchCount = 0
    private var rowCount = 0
    private var projectName = ""

    @SuppressLint("SetTextI18n")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // Initialize Views
        val timerTextView: TextView = findViewById(R.id.timerTextView)
        val stitchCountTextView: TextView = findViewById(R.id.stitchCountTextView)
        val rowCountTextView: TextView = findViewById(R.id.rowCountTextView)
        val projectNameEditText: EditText = findViewById(R.id.projectNameEditText)
        val startButton: Button = findViewById(R.id.startButton)
        val incrementStitchButton: Button = findViewById(R.id.incrementStitchButton)
        val incrementRowButton: Button = findViewById(R.id.incrementRowButton)
        val helpButton: Button = findViewById(R.id.helpButton)

        // Initialize Timer ViewModel
        timerViewModel = TimerViewModel(1000) { elapsedTime ->
            val seconds = elapsedTime / 1000
            timerTextView.text = "Time: $seconds s"
        }

        // Start timer when button clicked
        startButton.setOnClickListener {
            timerViewModel.start()
        }

        // Increment Stitch Count
        incrementStitchButton.setOnClickListener {
            stitchCount++
            stitchCountTextView.text = "Stitches: $stitchCount"
        }

        // Increment Row Count
        incrementRowButton.setOnClickListener {
            rowCount++
            rowCountTextView.text = "Rows: $rowCount"
        }

        // Capture project name input
        projectNameEditText.setOnEditorActionListener { _, _, _ ->
            projectName = projectNameEditText.text.toString()
            false
        }

        // Help Button
        helpButton.setOnClickListener {
            val intent = Intent(this, HelpActivity::class.java)
            startActivity(intent)
        }
    }
}