package com.example.stitchesandrows

import android.os.Handler
import android.os.Looper

class TimerViewModel(private val interval: Long, private val onTick: (Long) -> Unit) {
    private var startTime: Long = 0
    private var isRunning = false
    private val handler = Handler(Looper.getMainLooper())

    private val runnable = object : Runnable {
        override fun run() {
            if (isRunning) {
                val elapsedTime = System.currentTimeMillis() - startTime
                onTick(elapsedTime)
                handler.postDelayed(this, interval)
            }
        }
    }

    fun start() {
        if (!isRunning) {
            startTime = System.currentTimeMillis()
            isRunning = true
            handler.post(runnable)
        }
    }

    fun stop() {
        isRunning = false
        handler.removeCallbacks(runnable)
    }
}